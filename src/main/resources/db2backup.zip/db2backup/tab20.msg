SQL3104N  The Export utility is beginning to export data to file "tab20.ixf".

SQL3105N  The Export utility has finished exporting "70" rows.

